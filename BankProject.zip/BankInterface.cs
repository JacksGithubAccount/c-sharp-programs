﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BankProject
{
    interface BankInterface
    {
        //method headings
        void Withdraw();               
        void Deposit();
    }
}
