﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BankProject
{
    class notes
    {
        //solved: display account number - problem: wrong for loop statement
        //current: problem - repeating number in account number - need so all numbers are random

        //solved: problem - storing values into arrays - says null reference exception
        //         - solution: setting the values to the same type as the array - i.e. new MMCAClass
        // current: menu creation/streamreader - loading values into the array
    }
}
